ALX first group project. 
By Wanjiru and Mwangi.
